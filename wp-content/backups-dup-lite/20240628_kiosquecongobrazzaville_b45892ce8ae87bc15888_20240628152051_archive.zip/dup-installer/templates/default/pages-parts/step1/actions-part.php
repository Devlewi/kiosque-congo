<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

dupxTplRender('pages-parts/step1/actions/error');
dupxTplRender('pages-parts/step1/actions/validate');
dupxTplRender('pages-parts/step1/actions/next');
